/* tslint:disable */
/* eslint-disable */

/**
 * One bridge-owned graph and its opaque handle registry.
 *
 * The bridge owns the graph and all typed signal handles. Dropping this
 * value releases the graph. JavaScript must call `dispose` explicitly for
 * deterministic lifecycle behavior; no finalizer is used for correctness.
 */
export class WasmCore {
    free(): void;
    [Symbol.dispose](): void;
    begin_batch(): void;
    /**
     * Returns the validated `(slot, generation)` identity of a live
     * computation handle. The pair is metadata for the owning `WasmCore`
     * instance; it is not an authenticated handle constructor input.
     */
    computation_identity(computation: WasmHandle): Uint32Array;
    create_computation(): WasmHandle;
    create_dependency_list(): WasmDependencyList;
    create_signal(value: any): WasmHandle;
    /**
     * Explicitly drops the bridge-owned graph and all registered handles.
     */
    dispose(): void;
    dispose_computation(computation: WasmHandle): void;
    dispose_resource(handle: WasmHandle): void;
    dispose_signal(signal: WasmHandle): void;
    drain_pending_computations(): Uint32Array;
    end_batch(): void;
    constructor();
    read_signal(signal: WasmHandle): any;
    replace_dependencies(computation: WasmHandle, dependencies: WasmDependencyList): void;
    set_signal(signal: WasmHandle, value: any): boolean;
    subscribe(signal: WasmHandle, computation: WasmHandle): boolean;
    unsubscribe(signal: WasmHandle, computation: WasmHandle): boolean;
    /**
     * Returns whether explicit graph disposal has occurred.
     */
    readonly disposed: boolean;
}

/**
 * An opaque, instance-bound collection used for atomic dependency replacement.
 *
 * A JavaScript array cannot safely be downcast back into exported Rust handle
 * classes by wasm-bindgen. This list keeps the dependency operation typed and
 * preserves the owning instance before `WasmCore` performs its live-generation
 * validation.
 */
export class WasmDependencyList {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    clear(): void;
    is_empty(): boolean;
    len(): number;
    push(signal: WasmHandle): void;
}

/**
 * An opaque resource handle returned by the bridge.
 *
 * The fields are deliberately private. JavaScript can retain and pass this
 * object back to the same bridge instance, but cannot construct a trusted
 * handle by supplying slot or generation fields. Every operation validates
 * the fields against the owning instance and graph before calling the core.
 */
export class WasmHandle {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
}
