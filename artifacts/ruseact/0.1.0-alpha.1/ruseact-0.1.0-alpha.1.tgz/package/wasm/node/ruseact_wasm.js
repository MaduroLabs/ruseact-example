/* @ts-self-types="./ruseact_wasm.d.ts" */

/**
 * One bridge-owned graph and its opaque handle registry.
 *
 * The bridge owns the graph and all typed signal handles. Dropping this
 * value releases the graph. JavaScript must call `dispose` explicitly for
 * deterministic lifecycle behavior; no finalizer is used for correctness.
 */
class WasmCore {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        WasmCoreFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_wasmcore_free(ptr, 0);
    }
    begin_batch() {
        const ret = wasm.wasmcore_begin_batch(this.__wbg_ptr);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Returns the validated `(slot, generation)` identity of a live
     * computation handle. The pair is metadata for the owning `WasmCore`
     * instance; it is not an authenticated handle constructor input.
     * @param {WasmHandle} computation
     * @returns {Uint32Array}
     */
    computation_identity(computation) {
        _assertClass(computation, WasmHandle);
        const ret = wasm.wasmcore_computation_identity(this.__wbg_ptr, computation.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {WasmHandle}
     */
    create_computation() {
        const ret = wasm.wasmcore_create_computation(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WasmHandle.__wrap(ret[0]);
    }
    /**
     * @returns {WasmDependencyList}
     */
    create_dependency_list() {
        const ret = wasm.wasmcore_create_dependency_list(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WasmDependencyList.__wrap(ret[0]);
    }
    /**
     * @param {any} value
     * @returns {WasmHandle}
     */
    create_signal(value) {
        const ret = wasm.wasmcore_create_signal(this.__wbg_ptr, value);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WasmHandle.__wrap(ret[0]);
    }
    /**
     * Explicitly drops the bridge-owned graph and all registered handles.
     */
    dispose() {
        const ret = wasm.wasmcore_dispose(this.__wbg_ptr);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {WasmHandle} computation
     */
    dispose_computation(computation) {
        _assertClass(computation, WasmHandle);
        const ret = wasm.wasmcore_dispose_computation(this.__wbg_ptr, computation.__wbg_ptr);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {WasmHandle} handle
     */
    dispose_resource(handle) {
        _assertClass(handle, WasmHandle);
        const ret = wasm.wasmcore_dispose_resource(this.__wbg_ptr, handle.__wbg_ptr);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {WasmHandle} signal
     */
    dispose_signal(signal) {
        _assertClass(signal, WasmHandle);
        const ret = wasm.wasmcore_dispose_signal(this.__wbg_ptr, signal.__wbg_ptr);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Returns whether explicit graph disposal has occurred.
     * @returns {boolean}
     */
    get disposed() {
        const ret = wasm.wasmcore_disposed(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {Uint32Array}
     */
    drain_pending_computations() {
        const ret = wasm.wasmcore_drain_pending_computations(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    end_batch() {
        const ret = wasm.wasmcore_end_batch(this.__wbg_ptr);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    constructor() {
        const ret = wasm.wasmcore_new();
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0];
        WasmCoreFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * @param {WasmHandle} signal
     * @returns {any}
     */
    read_signal(signal) {
        _assertClass(signal, WasmHandle);
        const ret = wasm.wasmcore_read_signal(this.__wbg_ptr, signal.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {WasmHandle} computation
     * @param {WasmDependencyList} dependencies
     */
    replace_dependencies(computation, dependencies) {
        _assertClass(computation, WasmHandle);
        _assertClass(dependencies, WasmDependencyList);
        const ret = wasm.wasmcore_replace_dependencies(this.__wbg_ptr, computation.__wbg_ptr, dependencies.__wbg_ptr);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {WasmHandle} signal
     * @param {any} value
     * @returns {boolean}
     */
    set_signal(signal, value) {
        _assertClass(signal, WasmHandle);
        const ret = wasm.wasmcore_set_signal(this.__wbg_ptr, signal.__wbg_ptr, value);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] !== 0;
    }
    /**
     * @param {WasmHandle} signal
     * @param {WasmHandle} computation
     * @returns {boolean}
     */
    subscribe(signal, computation) {
        _assertClass(signal, WasmHandle);
        _assertClass(computation, WasmHandle);
        const ret = wasm.wasmcore_subscribe(this.__wbg_ptr, signal.__wbg_ptr, computation.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] !== 0;
    }
    /**
     * @param {WasmHandle} signal
     * @param {WasmHandle} computation
     * @returns {boolean}
     */
    unsubscribe(signal, computation) {
        _assertClass(signal, WasmHandle);
        _assertClass(computation, WasmHandle);
        const ret = wasm.wasmcore_unsubscribe(this.__wbg_ptr, signal.__wbg_ptr, computation.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] !== 0;
    }
}
if (Symbol.dispose) WasmCore.prototype[Symbol.dispose] = WasmCore.prototype.free;
exports.WasmCore = WasmCore;

/**
 * An opaque, instance-bound collection used for atomic dependency replacement.
 *
 * A JavaScript array cannot safely be downcast back into exported Rust handle
 * classes by wasm-bindgen. This list keeps the dependency operation typed and
 * preserves the owning instance before `WasmCore` performs its live-generation
 * validation.
 */
class WasmDependencyList {
    static __wrap(ptr) {
        const obj = Object.create(WasmDependencyList.prototype);
        obj.__wbg_ptr = ptr;
        WasmDependencyListFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        WasmDependencyListFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_wasmdependencylist_free(ptr, 0);
    }
    clear() {
        wasm.wasmdependencylist_clear(this.__wbg_ptr);
    }
    /**
     * @returns {boolean}
     */
    is_empty() {
        const ret = wasm.wasmdependencylist_is_empty(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {number}
     */
    len() {
        const ret = wasm.wasmdependencylist_len(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @param {WasmHandle} signal
     */
    push(signal) {
        _assertClass(signal, WasmHandle);
        const ret = wasm.wasmdependencylist_push(this.__wbg_ptr, signal.__wbg_ptr);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
}
if (Symbol.dispose) WasmDependencyList.prototype[Symbol.dispose] = WasmDependencyList.prototype.free;
exports.WasmDependencyList = WasmDependencyList;

/**
 * An opaque resource handle returned by the bridge.
 *
 * The fields are deliberately private. JavaScript can retain and pass this
 * object back to the same bridge instance, but cannot construct a trusted
 * handle by supplying slot or generation fields. Every operation validates
 * the fields against the owning instance and graph before calling the core.
 */
class WasmHandle {
    static __wrap(ptr) {
        const obj = Object.create(WasmHandle.prototype);
        obj.__wbg_ptr = ptr;
        WasmHandleFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        WasmHandleFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_wasmhandle_free(ptr, 0);
    }
}
if (Symbol.dispose) WasmHandle.prototype[Symbol.dispose] = WasmHandle.prototype.free;
exports.WasmHandle = WasmHandle;
function __wbg_get_imports() {
    const import0 = {
        __proto__: null,
        __wbg___wbindgen_boolean_get_4f1baf9a00be3c74: function(arg0) {
            const v = arg0;
            const ret = typeof(v) === 'boolean' ? v : undefined;
            return isLikeNone(ret) ? 0xFFFFFF : ret ? 1 : 0;
        },
        __wbg___wbindgen_number_get_934b640d0889af78: function(arg0, arg1) {
            const obj = arg1;
            const ret = typeof(obj) === 'number' ? obj : undefined;
            getDataViewMemory0().setFloat64((arg0 >>> 0) + 8 * 1, isLikeNone(ret) ? 0 : ret, true);
            getDataViewMemory0().setInt32((arg0 >>> 0) + 4 * 0, !isLikeNone(ret), true);
        },
        __wbg___wbindgen_string_get_7ce8eee7fd327545: function(arg0, arg1) {
            const obj = arg1;
            const ret = typeof(obj) === 'string' ? obj : undefined;
            var ptr1 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32((arg0 >>> 0) + 4 * 1, len1, true);
            getDataViewMemory0().setInt32((arg0 >>> 0) + 4 * 0, ptr1, true);
        },
        __wbg___wbindgen_throw_4c88d8bf264fd984: function(arg0, arg1) {
            throw new Error(getStringFromWasm0(arg0, arg1));
        },
        __wbg_new_cd4348290afae586: function() {
            const ret = new Object();
            return ret;
        },
        __wbg_new_from_slice_3512352010266e02: function(arg0, arg1) {
            const ret = new Uint32Array(getArrayU32FromWasm0(arg0, arg1));
            return ret;
        },
        __wbg_set_2793479888329cb6: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = Reflect.set(arg0, arg1, arg2);
            return ret;
        }, arguments); },
        __wbindgen_generic_0000000000000001: function(arg0) {
            // Cast intrinsic for `F64 -> Externref`.
            const ret = arg0;
            return ret;
        },
        __wbindgen_generic_0000000000000002: function(arg0, arg1) {
            // Cast intrinsic for `Ref(String) -> Externref`.
            const ret = getStringFromWasm0(arg0, arg1);
            return ret;
        },
        __wbindgen_init_externref_table: function() {
            const table = wasm.__wbindgen_externrefs;
            table.set(0, undefined);
            table.set(1024, undefined);
            table.set(1025, null);
            table.set(1026, true);
            table.set(1027, false);
        },
    };
    return {
        __proto__: null,
        "./ruseact_wasm_bg.js": import0,
    };
}

const WasmCoreFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_wasmcore_free(ptr, 1));
const WasmDependencyListFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_wasmdependencylist_free(ptr, 1));
const WasmHandleFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_wasmhandle_free(ptr, 1));

function addToExternrefTable0(obj) {
    const idx = wasm.__externref_table_alloc();
    wasm.__wbindgen_externrefs.set(idx, obj);
    return idx;
}

function _assertClass(instance, klass) {
    if (!(instance instanceof klass)) {
        throw new Error(`expected instance of ${klass.name}`);
    }
}

function getArrayU32FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint32ArrayMemory0().subarray(ptr / 4, ptr / 4 + len);
}

let cachedDataViewMemory0 = null;
function getDataViewMemory0() {
    if (cachedDataViewMemory0 === null || cachedDataViewMemory0.buffer.detached === true || (cachedDataViewMemory0.buffer.detached === undefined && cachedDataViewMemory0.buffer !== wasm.memory.buffer)) {
        cachedDataViewMemory0 = new DataView(wasm.memory.buffer);
    }
    return cachedDataViewMemory0;
}

function getStringFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return decodeText(getUint8ArrayMemory0().subarray(ptr, ptr + len));
}

let cachedUint32ArrayMemory0 = null;
function getUint32ArrayMemory0() {
    if (cachedUint32ArrayMemory0 === null || cachedUint32ArrayMemory0.byteLength === 0) {
        cachedUint32ArrayMemory0 = new Uint32Array(wasm.memory.buffer);
    }
    return cachedUint32ArrayMemory0;
}

let cachedUint8ArrayMemory0 = null;
function getUint8ArrayMemory0() {
    if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
        cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachedUint8ArrayMemory0;
}

function handleError(f, args) {
    try {
        return f.apply(this, args);
    } catch (e) {
        const idx = addToExternrefTable0(e);
        wasm.__wbindgen_exn_store(idx);
    }
}

function isLikeNone(x) {
    return x === undefined || x === null;
}

function passStringToWasm0(arg, malloc, realloc) {
    if (realloc === undefined) {
        const buf = cachedTextEncoder.encode(arg);
        const ptr = malloc(buf.length, 1) >>> 0;
        getUint8ArrayMemory0().subarray(ptr, ptr + buf.length).set(buf);
        WASM_VECTOR_LEN = buf.length;
        return ptr;
    }

    let len = arg.length;
    let ptr = malloc(len, 1) >>> 0;

    const mem = getUint8ArrayMemory0();

    let offset = 0;

    for (; offset < len; offset++) {
        const code = arg.charCodeAt(offset);
        if (code > 0x7F) break;
        mem[ptr + offset] = code;
    }
    if (offset !== len) {
        if (offset !== 0) {
            arg = arg.slice(offset);
        }
        ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
        const view = getUint8ArrayMemory0().subarray(ptr + offset, ptr + len);
        const ret = cachedTextEncoder.encodeInto(arg, view);

        offset += ret.written;
        ptr = realloc(ptr, len, offset, 1) >>> 0;
    }

    WASM_VECTOR_LEN = offset;
    return ptr;
}

function takeFromExternrefTable0(idx) {
    const value = wasm.__wbindgen_externrefs.get(idx);
    wasm.__externref_table_dealloc(idx);
    return value;
}

let cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true });
cachedTextDecoder.decode();
function decodeText(bytes) {
    return cachedTextDecoder.decode(bytes);
}

const cachedTextEncoder = new TextEncoder();

if (!('encodeInto' in cachedTextEncoder)) {
    cachedTextEncoder.encodeInto = function (arg, view) {
        const buf = cachedTextEncoder.encode(arg);
        view.set(buf);
        return {
            read: arg.length,
            written: buf.length
        };
    };
}

let WASM_VECTOR_LEN = 0;

const wasmPath = `${__dirname}/ruseact_wasm_bg.wasm`;
const wasmBytes = require('fs').readFileSync(wasmPath);
const wasmModule = new WebAssembly.Module(wasmBytes);
let wasmInstance = new WebAssembly.Instance(wasmModule, __wbg_get_imports());
let wasm = wasmInstance.exports;
wasm.__wbindgen_start();
