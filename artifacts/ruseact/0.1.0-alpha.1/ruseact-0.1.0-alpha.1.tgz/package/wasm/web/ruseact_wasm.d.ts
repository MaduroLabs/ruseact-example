/* tslint:disable */
/* eslint-disable */

/**
 * One bridge-owned graph and its opaque handle registry.
 *
 * The bridge owns the graph and all typed signal handles. Dropping this
 * value releases the graph. JavaScript must call `dispose` explicitly for
 * deterministic lifecycle behavior; no finalizer is used for correctness.
 */
export class WasmCore {
    free(): void;
    [Symbol.dispose](): void;
    begin_batch(): void;
    /**
     * Returns the validated `(slot, generation)` identity of a live
     * computation handle. The pair is metadata for the owning `WasmCore`
     * instance; it is not an authenticated handle constructor input.
     */
    computation_identity(computation: WasmHandle): Uint32Array;
    create_computation(): WasmHandle;
    create_dependency_list(): WasmDependencyList;
    create_signal(value: any): WasmHandle;
    /**
     * Explicitly drops the bridge-owned graph and all registered handles.
     */
    dispose(): void;
    dispose_computation(computation: WasmHandle): void;
    dispose_resource(handle: WasmHandle): void;
    dispose_signal(signal: WasmHandle): void;
    drain_pending_computations(): Uint32Array;
    end_batch(): void;
    constructor();
    read_signal(signal: WasmHandle): any;
    replace_dependencies(computation: WasmHandle, dependencies: WasmDependencyList): void;
    set_signal(signal: WasmHandle, value: any): boolean;
    subscribe(signal: WasmHandle, computation: WasmHandle): boolean;
    unsubscribe(signal: WasmHandle, computation: WasmHandle): boolean;
    /**
     * Returns whether explicit graph disposal has occurred.
     */
    readonly disposed: boolean;
}

/**
 * An opaque, instance-bound collection used for atomic dependency replacement.
 *
 * A JavaScript array cannot safely be downcast back into exported Rust handle
 * classes by wasm-bindgen. This list keeps the dependency operation typed and
 * preserves the owning instance before `WasmCore` performs its live-generation
 * validation.
 */
export class WasmDependencyList {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    clear(): void;
    is_empty(): boolean;
    len(): number;
    push(signal: WasmHandle): void;
}

/**
 * An opaque resource handle returned by the bridge.
 *
 * The fields are deliberately private. JavaScript can retain and pass this
 * object back to the same bridge instance, but cannot construct a trusted
 * handle by supplying slot or generation fields. Every operation validates
 * the fields against the owning instance and graph before calling the core.
 */
export class WasmHandle {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
}

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_wasmcore_free: (a: number, b: number) => void;
    readonly __wbg_wasmdependencylist_free: (a: number, b: number) => void;
    readonly __wbg_wasmhandle_free: (a: number, b: number) => void;
    readonly wasmcore_begin_batch: (a: number) => [number, number];
    readonly wasmcore_computation_identity: (a: number, b: number) => [number, number, number];
    readonly wasmcore_create_computation: (a: number) => [number, number, number];
    readonly wasmcore_create_dependency_list: (a: number) => [number, number, number];
    readonly wasmcore_create_signal: (a: number, b: any) => [number, number, number];
    readonly wasmcore_dispose: (a: number) => [number, number];
    readonly wasmcore_dispose_computation: (a: number, b: number) => [number, number];
    readonly wasmcore_dispose_resource: (a: number, b: number) => [number, number];
    readonly wasmcore_dispose_signal: (a: number, b: number) => [number, number];
    readonly wasmcore_disposed: (a: number) => number;
    readonly wasmcore_drain_pending_computations: (a: number) => [number, number, number];
    readonly wasmcore_end_batch: (a: number) => [number, number];
    readonly wasmcore_new: () => [number, number, number];
    readonly wasmcore_read_signal: (a: number, b: number) => [number, number, number];
    readonly wasmcore_replace_dependencies: (a: number, b: number, c: number) => [number, number];
    readonly wasmcore_set_signal: (a: number, b: number, c: any) => [number, number, number];
    readonly wasmcore_subscribe: (a: number, b: number, c: number) => [number, number, number];
    readonly wasmcore_unsubscribe: (a: number, b: number, c: number) => [number, number, number];
    readonly wasmdependencylist_clear: (a: number) => void;
    readonly wasmdependencylist_is_empty: (a: number) => number;
    readonly wasmdependencylist_len: (a: number) => number;
    readonly wasmdependencylist_push: (a: number, b: number) => [number, number];
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
